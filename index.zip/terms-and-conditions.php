<?php
require_once __DIR__ . '/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Terms &amp; Conditions — ZAMZY Digital Engineering | Hitech City, Hyderabad</title>
  <meta name="description" content="Terms & Conditions for ZAMZY Digital Solutions. Master Services Agreement, Razorpay & PayPal payment terms, IP ownership transfer, and SLAs." />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://zamzy.in/terms-and-conditions.php" />

  <!-- Fonts & Core Styles -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="tooplate-vora-bold-style.css" />

  <style>
    .legal-page-hero {
      padding: 130px 5vw 40px 5vw;
      text-align: center;
      position: relative;
      z-index: 2;
    }
    .legal-hero__eyebrow {
      font-family: var(--mono);
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      color: var(--cyan);
      text-transform: uppercase;
      margin-bottom: 0.8rem;
    }
    .legal-hero__title {
      font-family: var(--display);
      font-size: clamp(2rem, 4.5vw, 3.4rem);
      font-weight: 700;
      color: var(--white);
      margin-bottom: 1rem;
    }
    .legal-hero__meta {
      font-family: var(--mono);
      font-size: 0.8rem;
      color: var(--dim);
    }

    .legal-content-container {
      max-width: 900px;
      margin: 0 auto;
      padding: 20px 5vw 100px 5vw;
      position: relative;
      z-index: 2;
    }
    .legal-box {
      background: rgba(10, 10, 18, 0.85);
      border: 1px solid rgba(6, 182, 212, 0.25);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 3rem 2.5rem;
      color: var(--dim);
      font-family: var(--mono);
      font-size: 0.88rem;
      line-height: 1.8;
      box-shadow: 0 0 40px rgba(0, 0, 0, 0.6);
    }
    .legal-box h2 {
      font-family: var(--display);
      font-size: 1.35rem;
      color: var(--white);
      margin: 2rem 0 0.8rem 0;
      padding-bottom: 0.4rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    .legal-box h2:first-child {
      margin-top: 0;
    }
    .legal-box p {
      margin-bottom: 1.2rem;
    }
    .legal-box ul {
      margin: 0.5rem 0 1.2rem 1.5rem;
      list-style-type: square;
    }
    .legal-box li {
      margin-bottom: 0.5rem;
    }
    .legal-highlight {
      color: var(--cyan);
      font-weight: 600;
    }
  </style>
</head>
<body>

  <!-- Ambient Cosmic Aura -->
  <div class="aura"></div>

  <!-- Navigation Bar -->
  <nav class="nav">
    <a href="index.html" class="brand-logo-wrap">
      <img src="images/logo.png" alt="ZAMZY" class="brand-logo-img" />
    </a>
    <ul class="nav-links">
      <li><a href="index.html#about">Studio</a></li>
      <li><a href="index.html#launchpad">Launchpad</a></li>
      <li><a href="index.html#products">Products</a></li>
      <li><a href="index.html#services">Services</a></li>
      <li><a href="index.html#testimonials">Reviews</a></li>
      <li><a href="index.html#rates">Rates</a></li>
      <li><a href="careers">Careers</a></li>
      <li><a href="contact.php">Contact</a></li>
    </ul>
    <button class="menu-toggle" aria-label="Open menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </nav>

  <!-- Mobile Drawer Menu -->
  <div class="mobile-menu">
    <a href="index.html#hero">Hero</a>
    <a href="index.html#about">Studio</a>
    <a href="index.html#products">Products</a>
    <a href="index.html#services">Services</a>
    <a href="careers">Careers &amp; Guild</a>
    <a href="contact.php">Contact</a>
  </div>

  <!-- Legal Hero Header -->
  <header class="legal-page-hero">
    <div class="legal-hero__eyebrow">MASTER SERVICE AGREEMENT &amp; TERMS</div>
    <h1 class="legal-hero__title">Terms &amp; Conditions</h1>
    <div class="legal-hero__meta">
      Entity: ZAMZY DIGITAL SOLUTIONS · Effective Date: January 1, 2026 · Jurisdiction: Hyderabad, Telangana, India
    </div>
  </header>

  <!-- Main Legal Document Content -->
  <main class="legal-content-container">
    <div class="legal-box">
      
      <h2>1. Agreement Acceptance</h2>
      <p>
        These Terms &amp; Conditions govern the use of the platform <a href="https://zamzy.in" class="legal-highlight">zamzy.in</a> and all custom software engineering services provided by <span class="legal-highlight">ZAMZY DIGITAL SOLUTIONS</span> ("ZAMZY", "we", "us"). By placing an order, submitting a project brief, executing a milestone payment, or subscribing to our SaaS platforms, you agree to be legally bound by these terms.
      </p>

      <h2>2. Engineering Services Scope &amp; Deliverables</h2>
      <p>ZAMZY provides custom digital solutions including but not limited to:</p>
      <ul>
        <li>Full-Stack SaaS Application Development (Next.js, Node.js, Python, Go, PostgreSQL).</li>
        <li>Mobile App Development (iOS &amp; Android via Flutter / Native).</li>
        <li>School &amp; Enterprise ERP Ecosystems.</li>
        <li>IVR Telephony &amp; WhatsApp Business API Gateways.</li>
        <li>Cloud Infrastructure, DevOps &amp; High-Concurrency Monitoring.</li>
      </ul>
      <p>Specific project milestones, technical deliverables, timelines, and pricing are defined in individual Statements of Work (SOW) or project proposals agreed upon prior to project initiation.</p>

      <h2>3. Payment Terms &amp; Payment Gateways (Razorpay &amp; PayPal)</h2>
      <p>
        All billing and payment processing on zamzy.in are subject to the following terms:
      </p>
      <ul>
        <li><strong>Milestone Payments:</strong> Projects are billed based on agreed milestone schedules (e.g. 40% initial deposit, 30% alpha demo delivery, 30% final code deployment).</li>
        <li><strong>Approved Payment Gateways:</strong> We process payments online through PCI-DSS Level 1 certified gateways: <span class="legal-highlight">Razorpay</span> (INR / UPI / Cards / Netbanking) and <span class="legal-highlight">PayPal</span> (International Multi-Currency).</li>
        <li><strong>Currency:</strong> Unless otherwise specified in writing, domestic Indian invoices are in INR (₹) and international invoices are in USD ($).</li>
        <li><strong>Taxes:</strong> Prices quoted are exclusive of applicable Indian GST (18%) or local taxes where required by law.</li>
      </ul>

      <h2>4. Intellectual Property &amp; Git Repository Ownership</h2>
      <p>
        Upon receipt of 100% full invoice clearance for any completed milestone or project:
      </p>
      <ul>
        <li>ZAMZY transfers full, unencumbered Intellectual Property (IP) ownership of custom source code, database schemas, and documentation to the Client.</li>
        <li>Full admin access to Git repositories (GitHub/GitLab) and cloud infrastructure (AWS/GCP/Cloudflare) is handed over to the Client.</li>
        <li>ZAMZY retains non-exclusive rights to core reusable utility libraries, frameworks, or open-source components embedded within the deliverable.</li>
      </ul>

      <h2>5. Warranties &amp; 30-Day Post-Launch SLA</h2>
      <p>
        All custom engineering projects include a <span class="legal-highlight">30-day post-launch warranty SLA</span> covering bug fixes, emergency patch deployments, and concurrency tuning for features defined within the original scope brief. Modifications outside agreed SOW are subject to change order fees.
      </p>

      <h2>6. Governing Law &amp; Dispute Resolution</h2>
      <p>
        These Terms shall be governed by and construed in accordance with the laws of India. Any legal disputes or claims arising under this agreement shall be subject to the exclusive jurisdiction of the competent courts in <span class="legal-highlight">Hyderabad, Telangana, India</span>.
      </p>

      <h2>7. Merchant Contact Information</h2>
      <p>For questions or formal legal notices regarding these Terms &amp; Conditions, please contact:</p>
      <p>
        <strong>Legal Desk:</strong> ZAMZY Digital Solutions<br />
        <strong>Address:</strong> Hitech City, Hyderabad, Telangana 500081, India.<br />
        <strong>Email:</strong> <a href="mailto:contact@zamzy.in" class="legal-highlight">contact@zamzy.in</a> / <a href="mailto:support@zamzy.in" class="legal-highlight">support@zamzy.in</a><br />
        <strong>WhatsApp Support:</strong> <a href="https://wa.me/919876543210" class="legal-highlight">+91 98765 43210</a>
      </p>

    </div>
  </main>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-inner">
      <div class="footer-brand">
        <div class="footer-logo">
          <img src="images/logo.png" alt="ZAMZY" class="brand-logo-img" />
        </div>
        <p class="footer-tagline">
          ZAMZY.IN — Engineering High-Performance SaaS Platforms, Mobile Ecosystems &amp; Automated Cloud Systems.
        </p>
        <span class="footer-copy">© 2026 ZAMZY Digital Engineering Agency. All rights reserved.</span>
      </div>

      <div>
        <div class="footer-col-title">Navigation</div>
        <div class="footer-links-col">
          <a href="index.html#hero">Home</a>
          <a href="index.html#about">Studio</a>
          <a href="index.html#launchpad">Launchpad</a>
          <a href="index.html#products">Products</a>
          <a href="index.html#services">Services</a>
          <a href="careers">Careers &amp; Guild</a>
          <a href="contact.php">Contact Us</a>
        </div>
      </div>

      <div>
        <div class="footer-col-title">Merchant Policies</div>
        <div class="footer-links-col">
          <a href="privacy-policy.php">Privacy Policy</a>
          <a href="terms-and-conditions.php" style="color:var(--cyan);">Terms &amp; Conditions</a>
          <a href="refund-policy.php">Refund &amp; Cancellation</a>
          <a href="shipping-policy.php">Shipping &amp; Delivery</a>
          <a href="contact.php">Contact Support</a>
        </div>
      </div>

      <div>
        <div class="footer-col-title">Engineering Office</div>
        <div class="footer-links-col" style="font-size:0.82rem; color:var(--dim); line-height:1.7;">
          <p><strong>ZAMZY DIGITAL SOLUTIONS</strong></p>
          <p>📍 Hitech City, Hyderabad, Telangana, India</p>
          <p>💬 <a href="https://wa.me/919876543210" target="_blank" style="color:var(--cyan); text-decoration:underline;">+91 98765 43210 (WhatsApp)</a></p>
          <p>✉️ <a href="mailto:contact@zamzy.in" style="color:var(--cyan); text-decoration:underline;">contact@zamzy.in</a></p>
        </div>
      </div>
    </div>

    <div class="footer-bottom-bar">
      <div class="footer-bottom-text">
        ⚡ High-Concurrency Systems · 99.9% Uptime SLA · Hitech City, Hyderabad
      </div>
      <div class="footer-social-links">
        <a href="privacy-policy.php" class="footer-social-link">Privacy Policy</a>
        <a href="terms-and-conditions.php" class="footer-social-link">Terms &amp; Conditions</a>
        <a href="refund-policy.php" class="footer-social-link">Refund Policy</a>
        <a href="shipping-policy.php" class="footer-social-link">Shipping Policy</a>
      </div>
    </div>
  </footer>

  <script src="tooplate-vora-bold-script.js"></script>
</body>
</html>
