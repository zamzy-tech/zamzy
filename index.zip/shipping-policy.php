<?php
require_once __DIR__ . '/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Shipping &amp; Delivery Policy — ZAMZY Digital Engineering | Hitech City, Hyderabad</title>
  <meta name="description" content="Shipping & Delivery Policy for ZAMZY Digital Solutions. Electronic delivery policy for software repositories, cloud deployments, and SaaS product credentials." />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://zamzy.in/shipping-policy.php" />

  <!-- Fonts & Core Styles -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="tooplate-vora-bold-style.css" />

  <style>
    .legal-page-hero {
      padding: 130px 5vw 40px 5vw;
      text-align: center;
      position: relative;
      z-index: 2;
    }
    .legal-hero__eyebrow {
      font-family: var(--mono);
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      color: var(--cyan);
      text-transform: uppercase;
      margin-bottom: 0.8rem;
    }
    .legal-hero__title {
      font-family: var(--display);
      font-size: clamp(2rem, 4.5vw, 3.4rem);
      font-weight: 700;
      color: var(--white);
      margin-bottom: 1rem;
    }
    .legal-hero__meta {
      font-family: var(--mono);
      font-size: 0.8rem;
      color: var(--dim);
    }

    .legal-content-container {
      max-width: 900px;
      margin: 0 auto;
      padding: 20px 5vw 100px 5vw;
      position: relative;
      z-index: 2;
    }
    .legal-box {
      background: rgba(10, 10, 18, 0.85);
      border: 1px solid rgba(6, 182, 212, 0.25);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 3rem 2.5rem;
      color: var(--dim);
      font-family: var(--mono);
      font-size: 0.88rem;
      line-height: 1.8;
      box-shadow: 0 0 40px rgba(0, 0, 0, 0.6);
    }
    .legal-box h2 {
      font-family: var(--display);
      font-size: 1.35rem;
      color: var(--white);
      margin: 2rem 0 0.8rem 0;
      padding-bottom: 0.4rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    .legal-box h2:first-child {
      margin-top: 0;
    }
    .legal-box p {
      margin-bottom: 1.2rem;
    }
    .legal-box ul {
      margin: 0.5rem 0 1.2rem 1.5rem;
      list-style-type: square;
    }
    .legal-box li {
      margin-bottom: 0.5rem;
    }
    .legal-highlight {
      color: var(--cyan);
      font-weight: 600;
    }
  </style>
</head>
<body>

  <!-- Ambient Cosmic Aura -->
  <div class="aura"></div>

  <!-- Navigation Bar -->
  <nav class="nav">
    <a href="index.html" class="brand-logo-wrap">
      <img src="images/logo.png" alt="ZAMZY" class="brand-logo-img" />
    </a>
    <ul class="nav-links">
      <li><a href="index.html#about">Studio</a></li>
      <li><a href="index.html#launchpad">Launchpad</a></li>
      <li><a href="index.html#products">Products</a></li>
      <li><a href="index.html#services">Services</a></li>
      <li><a href="index.html#testimonials">Reviews</a></li>
      <li><a href="index.html#rates">Rates</a></li>
      <li><a href="careers">Careers</a></li>
      <li><a href="contact.php">Contact</a></li>
    </ul>
    <button class="menu-toggle" aria-label="Open menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </nav>

  <!-- Mobile Drawer Menu -->
  <div class="mobile-menu">
    <a href="index.html#hero">Hero</a>
    <a href="index.html#about">Studio</a>
    <a href="index.html#products">Products</a>
    <a href="index.html#services">Services</a>
    <a href="careers">Careers &amp; Guild</a>
    <a href="contact.php">Contact</a>
  </div>

  <!-- Legal Hero Header -->
  <header class="legal-page-hero">
    <div class="legal-hero__eyebrow">DIGITAL SERVICE FULFILLMENT &amp; DELIVERY</div>
    <h1 class="legal-hero__title">Shipping &amp; Delivery Policy</h1>
    <div class="legal-hero__meta">
      Entity: ZAMZY DIGITAL SOLUTIONS · Effective Date: January 1, 2026 · Delivery Mode: 100% Electronic
    </div>
  </header>

  <!-- Main Legal Document Content -->
  <main class="legal-content-container">
    <div class="legal-box">
      
      <h2>1. Electronic Digital Delivery Scope</h2>
      <p>
        <span class="legal-highlight">ZAMZY DIGITAL SOLUTIONS</span> ("ZAMZY") is a registered software engineering agency specializing exclusively in digital products, custom SaaS applications, cloud infrastructure deployments, and enterprise software.
      </p>
      <p>
        <span class="legal-highlight">WE DO NOT SHIP PHYSICAL GOODS.</span> All services, source code deliverables, sandbox demo credentials, and software deployment scripts are delivered <strong>100% electronically</strong> over secure digital networks. Zero physical shipping, freight, or handling fees apply.
      </p>

      <h2>2. Delivery Methods &amp; Channels</h2>
      <p>Digital engineering assets are delivered through the following encrypted channels:</p>
      <ul>
        <li><strong>Source Code &amp; Repositories:</strong> Transferred directly to the client's GitHub, GitLab, or Bitbucket organization.</li>
        <li><strong>Cloud Deployments:</strong> Provisioned directly on client cloud environments (AWS, GCP, DigitalOcean, Cloudflare, Docker).</li>
        <li><strong>SaaS Sandbox Credentials:</strong> Dispatched electronically to the client's verified Email and WhatsApp number.</li>
        <li><strong>Documentation &amp; License Keys:</strong> Sent via encrypted PDF / Markdown documentation links via Email.</li>
      </ul>

      <h2>3. Standard Delivery Timelines</h2>
      <p>Delivery timelines vary depending on the service tier selected:</p>
      <ul>
        <li><strong>SaaS Sandbox &amp; Product Demos:</strong> Delivered within <span class="legal-highlight">5 minutes to 2 hours</span> of form submission.</li>
        <li><strong>Custom MVP &amp; Web Milestones:</strong> Delivered within <strong>1 to 2 weeks</strong> as specified in the agreed project SOW.</li>
        <li><strong>Enterprise Software &amp; ERP Platforms:</strong> Delivered in phased milestones over <strong>2 to 6 weeks</strong>.</li>
      </ul>

      <h2>4. Proof of Delivery &amp; Milestone Sign-off</h2>
      <p>
        Proof of electronic delivery is established via digital logs including Git commit hashes, cloud deployment verification receipts, and email dispatch confirmations sent to the client's registered contact details.
      </p>

      <h2>5. Delivery Support &amp; Assistance</h2>
      <p>If you experience any delays receiving your digital deliverables or sandbox access credentials, please contact our 24/7 technical desk:</p>
      <p>
        <strong>Delivery Support Desk:</strong> ZAMZY Digital Solutions<br />
        <strong>Address:</strong> Hitech City, Hyderabad, Telangana 500081, India.<br />
        <strong>Email:</strong> <a href="mailto:contact@zamzy.in" class="legal-highlight">contact@zamzy.in</a> / <a href="mailto:support@zamzy.in" class="legal-highlight">support@zamzy.in</a><br />
        <strong>WhatsApp Support:</strong> <a href="https://wa.me/919876543210" class="legal-highlight">+91 98765 43210</a>
      </p>

    </div>
  </main>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-inner">
      <div class="footer-brand">
        <div class="footer-logo">
          <img src="images/logo.png" alt="ZAMZY" class="brand-logo-img" />
        </div>
        <p class="footer-tagline">
          ZAMZY.IN — Engineering High-Performance SaaS Platforms, Mobile Ecosystems &amp; Automated Cloud Systems.
        </p>
        <span class="footer-copy">© 2026 ZAMZY Digital Engineering Agency. All rights reserved.</span>
      </div>

      <div>
        <div class="footer-col-title">Navigation</div>
        <div class="footer-links-col">
          <a href="index.html#hero">Home</a>
          <a href="index.html#about">Studio</a>
          <a href="index.html#launchpad">Launchpad</a>
          <a href="index.html#products">Products</a>
          <a href="index.html#services">Services</a>
          <a href="careers">Careers &amp; Guild</a>
          <a href="contact.php">Contact Us</a>
        </div>
      </div>

      <div>
        <div class="footer-col-title">Merchant Policies</div>
        <div class="footer-links-col">
          <a href="privacy-policy.php">Privacy Policy</a>
          <a href="terms-and-conditions.php">Terms &amp; Conditions</a>
          <a href="refund-policy.php">Refund &amp; Cancellation</a>
          <a href="shipping-policy.php" style="color:var(--cyan);">Shipping &amp; Delivery</a>
          <a href="contact.php">Contact Support</a>
        </div>
      </div>

      <div>
        <div class="footer-col-title">Engineering Office</div>
        <div class="footer-links-col" style="font-size:0.82rem; color:var(--dim); line-height:1.7;">
          <p><strong>ZAMZY DIGITAL SOLUTIONS</strong></p>
          <p>📍 Hitech City, Hyderabad, Telangana, India</p>
          <p>💬 <a href="https://wa.me/919876543210" target="_blank" style="color:var(--cyan); text-decoration:underline;">+91 98765 43210 (WhatsApp)</a></p>
          <p>✉️ <a href="mailto:contact@zamzy.in" style="color:var(--cyan); text-decoration:underline;">contact@zamzy.in</a></p>
        </div>
      </div>
    </div>

    <div class="footer-bottom-bar">
      <div class="footer-bottom-text">
        ⚡ High-Concurrency Systems · 99.9% Uptime SLA · Hitech City, Hyderabad
      </div>
      <div class="footer-social-links">
        <a href="privacy-policy.php" class="footer-social-link">Privacy Policy</a>
        <a href="terms-and-conditions.php" class="footer-social-link">Terms &amp; Conditions</a>
        <a href="refund-policy.php" class="footer-social-link">Refund Policy</a>
        <a href="shipping-policy.php" class="footer-social-link">Shipping Policy</a>
      </div>
    </div>
  </footer>

  <script src="tooplate-vora-bold-script.js"></script>
</body>
</html>
