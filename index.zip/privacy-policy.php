<?php
require_once __DIR__ . '/db.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
  <title>Privacy Policy — ZAMZY Digital Engineering | Hitech City, Hyderabad</title>
  <meta name="description" content="Privacy Policy for ZAMZY Digital Solutions. Learn how we handle client project briefs, payment data through Razorpay & PayPal, and personal information under DPDP Act 2023 & GDPR." />
  <meta name="robots" content="index, follow" />
  <link rel="canonical" href="https://zamzy.in/privacy-policy.php" />

  <!-- Fonts & Core Styles -->
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="tooplate-vora-bold-style.css" />

  <style>
    .legal-page-hero {
      padding: 130px 5vw 40px 5vw;
      text-align: center;
      position: relative;
      z-index: 2;
    }
    .legal-hero__eyebrow {
      font-family: var(--mono);
      font-size: 0.75rem;
      letter-spacing: 0.25em;
      color: var(--cyan);
      text-transform: uppercase;
      margin-bottom: 0.8rem;
    }
    .legal-hero__title {
      font-family: var(--display);
      font-size: clamp(2rem, 4.5vw, 3.4rem);
      font-weight: 700;
      color: var(--white);
      margin-bottom: 1rem;
    }
    .legal-hero__meta {
      font-family: var(--mono);
      font-size: 0.8rem;
      color: var(--dim);
    }

    .legal-content-container {
      max-width: 900px;
      margin: 0 auto;
      padding: 20px 5vw 100px 5vw;
      position: relative;
      z-index: 2;
    }
    .legal-box {
      background: rgba(10, 10, 18, 0.85);
      border: 1px solid rgba(6, 182, 212, 0.25);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 20px;
      padding: 3rem 2.5rem;
      color: var(--dim);
      font-family: var(--mono);
      font-size: 0.88rem;
      line-height: 1.8;
      box-shadow: 0 0 40px rgba(0, 0, 0, 0.6);
    }
    .legal-box h2 {
      font-family: var(--display);
      font-size: 1.35rem;
      color: var(--white);
      margin: 2rem 0 0.8rem 0;
      padding-bottom: 0.4rem;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }
    .legal-box h2:first-child {
      margin-top: 0;
    }
    .legal-box p {
      margin-bottom: 1.2rem;
    }
    .legal-box ul {
      margin: 0.5rem 0 1.2rem 1.5rem;
      list-style-type: square;
    }
    .legal-box li {
      margin-bottom: 0.5rem;
    }
    .legal-highlight {
      color: var(--cyan);
      font-weight: 600;
    }
  </style>
</head>
<body>

  <!-- Ambient Cosmic Aura -->
  <div class="aura"></div>

  <!-- Navigation Bar -->
  <nav class="nav">
    <a href="index.html" class="brand-logo-wrap">
      <img src="images/logo.png" alt="ZAMZY" class="brand-logo-img" />
    </a>
    <ul class="nav-links">
      <li><a href="index.html#about">Studio</a></li>
      <li><a href="index.html#launchpad">Launchpad</a></li>
      <li><a href="index.html#products">Products</a></li>
      <li><a href="index.html#services">Services</a></li>
      <li><a href="index.html#testimonials">Reviews</a></li>
      <li><a href="index.html#rates">Rates</a></li>
      <li><a href="careers">Careers</a></li>
      <li><a href="contact.php">Contact</a></li>
    </ul>
    <button class="menu-toggle" aria-label="Open menu" aria-expanded="false">
      <span></span><span></span><span></span>
    </button>
  </nav>

  <!-- Mobile Drawer Menu -->
  <div class="mobile-menu">
    <a href="index.html#hero">Hero</a>
    <a href="index.html#about">Studio</a>
    <a href="index.html#products">Products</a>
    <a href="index.html#services">Services</a>
    <a href="careers">Careers &amp; Guild</a>
    <a href="contact.php">Contact</a>
  </div>

  <!-- Legal Hero Header -->
  <header class="legal-page-hero">
    <div class="legal-hero__eyebrow">LEGAL &amp; COMPLIANCE DIRECTIVE</div>
    <h1 class="legal-hero__title">Privacy Policy</h1>
    <div class="legal-hero__meta">
      Entity: ZAMZY DIGITAL SOLUTIONS · Effective Date: January 1, 2026 · Location: Hitech City, Hyderabad
    </div>
  </header>

  <!-- Main Legal Document Content -->
  <main class="legal-content-container">
    <div class="legal-box">
      
      <h2>1. Introduction &amp; Entity Overview</h2>
      <p>
        Welcome to <span class="legal-highlight">ZAMZY DIGITAL SOLUTIONS</span> ("ZAMZY", "we", "our", or "us"). We operate the platform <a href="https://zamzy.in" class="legal-highlight">zamzy.in</a> and specialize in high-concurrency SaaS engineering, custom web applications, mobile software, ERP systems, and cloud architecture in Hitech City, Hyderabad, Telangana, India.
      </p>
      <p>
        This Privacy Policy details how we collect, process, protect, and handle client information when you visit our website, submit a project brief, request product sandbox credentials, or execute milestone payments via our PCI-DSS compliant payment gateways (<span class="legal-highlight">Razorpay</span> and <span class="legal-highlight">PayPal</span>).
      </p>

      <h2>2. Information We Collect</h2>
      <p>We collect information necessary to deliver software engineering services and fulfill contractual SLAs:</p>
      <ul>
        <li><strong>Personal Identifiers:</strong> Full Name, Email Address, WhatsApp / Phone Number, Company Name, Designation.</li>
        <li><strong>Project &amp; Technical Requirements:</strong> Scope briefs, budget estimates, tech stack preferences, preferred language.</li>
        <li><strong>Transaction Data:</strong> Payment milestone amounts, invoice reference numbers, order IDs generated by payment gateways. <span class="legal-highlight">Note: We NEVER store your raw credit card numbers, CVVs, or UPI PINs. All payment transactions are securely handled directly by Razorpay and PayPal.</span></li>
        <li><strong>Automated Telemetry &amp; Log Data:</strong> IP Address, browser type, device metadata, operating system, and referral URLs collected for cybersecurity and anti-fraud monitoring.</li>
      </ul>

      <h2>3. Purpose &amp; Usage of Collected Information</h2>
      <p>ZAMZY uses collected data strictly for legitimate engineering &amp; operational purposes:</p>
      <ul>
        <li>To evaluate project briefs and schedule technical consultations with our Lead Solution Architect.</li>
        <li>To process invoices and milestone payments securely via Razorpay and PayPal.</li>
        <li>To dispatch ready-made product sandbox credentials via WhatsApp and Email.</li>
        <li>To execute Mutual Non-Disclosure Agreements (NDAs) and IP Git repository ownership transfers.</li>
        <li>To comply with statutory financial auditing laws in India.</li>
      </ul>

      <h2>4. Payment Security &amp; Third-Party Processing (Razorpay &amp; PayPal)</h2>
      <p>
        All financial transactions conducted on zamzy.in are encrypted using 256-bit SSL encryption. We partner with Tier-1 PCI-DSS Level 1 certified payment processing networks:
      </p>
      <ul>
        <li><strong>Razorpay Software Private Limited:</strong> Handles Indian Rupee (INR) transactions including UPI, Netbanking, Credit/Debit Cards, and Corporate Wallets.</li>
        <li><strong>PayPal Inc. / PayPal Payments Private Limited:</strong> Handles international cross-border transactions (USD, EUR, GBP, SGD, etc.).</li>
      </ul>
      <p>
        ZAMZY does not sell, rent, trade, or leak your personal or business data to third-party data brokers or marketing lists. Zero spam policy strictly enforced.
      </p>

      <h2>5. Data Retention &amp; Intellectual Property Privacy</h2>
      <p>
        Client project briefs, codebases, database schemas, and NDA agreements are stored on encrypted cloud servers with access restricted exclusively to assigned engineering personnel. Upon invoice clearance and Git repository handoff, clients retain 100% intellectual property ownership.
      </p>

      <h2>6. Your Rights Under DPDP Act 2023 &amp; GDPR</h2>
      <p>You have the right to request access to your personal data, request correction of inaccurate metadata, or request complete erasure of your contact record from our active database by emailing <a href="mailto:contact@zamzy.in" class="legal-highlight">contact@zamzy.in</a>.</p>

      <h2>7. Grievance Redressal Officer &amp; Contact Information</h2>
      <p>For any privacy queries, data requests, or payment compliance questions, please contact our Compliance Team:</p>
      <p>
        <strong>Grievance Officer:</strong> Legal &amp; Compliance Lead<br />
        <strong>Registered Office:</strong> ZAMZY Digital Solutions, Hitech City, Hyderabad, Telangana 500081, India.<br />
        <strong>Email:</strong> <a href="mailto:contact@zamzy.in" class="legal-highlight">contact@zamzy.in</a> / <a href="mailto:support@zamzy.in" class="legal-highlight">support@zamzy.in</a><br />
        <strong>Phone / WhatsApp Support:</strong> <a href="https://wa.me/919876543210" class="legal-highlight">+91 98765 43210</a>
      </p>

    </div>
  </main>

  <!-- Footer -->
  <footer class="footer">
    <div class="footer-inner">
      <div class="footer-brand">
        <div class="footer-logo">
          <img src="images/logo.png" alt="ZAMZY" class="brand-logo-img" />
        </div>
        <p class="footer-tagline">
          ZAMZY.IN — Engineering High-Performance SaaS Platforms, Mobile Ecosystems &amp; Automated Cloud Systems.
        </p>
        <span class="footer-copy">© 2026 ZAMZY Digital Engineering Agency. All rights reserved.</span>
      </div>

      <div>
        <div class="footer-col-title">Navigation</div>
        <div class="footer-links-col">
          <a href="index.html#hero">Home</a>
          <a href="index.html#about">Studio</a>
          <a href="index.html#launchpad">Launchpad</a>
          <a href="index.html#products">Products</a>
          <a href="index.html#services">Services</a>
          <a href="careers">Careers &amp; Guild</a>
          <a href="contact.php">Contact Us</a>
        </div>
      </div>

      <div>
        <div class="footer-col-title">Merchant Policies</div>
        <div class="footer-links-col">
          <a href="privacy-policy.php" style="color:var(--cyan);">Privacy Policy</a>
          <a href="terms-and-conditions.php">Terms &amp; Conditions</a>
          <a href="refund-policy.php">Refund &amp; Cancellation</a>
          <a href="shipping-policy.php">Shipping &amp; Delivery</a>
          <a href="contact.php">Contact Support</a>
        </div>
      </div>

      <div>
        <div class="footer-col-title">Engineering Office</div>
        <div class="footer-links-col" style="font-size:0.82rem; color:var(--dim); line-height:1.7;">
          <p><strong>ZAMZY DIGITAL SOLUTIONS</strong></p>
          <p>📍 Hitech City, Hyderabad, Telangana, India</p>
          <p>💬 <a href="https://wa.me/919876543210" target="_blank" style="color:var(--cyan); text-decoration:underline;">+91 98765 43210 (WhatsApp)</a></p>
          <p>✉️ <a href="mailto:contact@zamzy.in" style="color:var(--cyan); text-decoration:underline;">contact@zamzy.in</a></p>
        </div>
      </div>
    </div>

    <div class="footer-bottom-bar">
      <div class="footer-bottom-text">
        ⚡ High-Concurrency Systems · 99.9% Uptime SLA · Hitech City, Hyderabad
      </div>
      <div class="footer-social-links">
        <a href="privacy-policy.php" class="footer-social-link">Privacy Policy</a>
        <a href="terms-and-conditions.php" class="footer-social-link">Terms &amp; Conditions</a>
        <a href="refund-policy.php" class="footer-social-link">Refund Policy</a>
        <a href="shipping-policy.php" class="footer-social-link">Shipping Policy</a>
      </div>
    </div>
  </footer>

  <script src="tooplate-vora-bold-script.js"></script>
</body>
</html>
